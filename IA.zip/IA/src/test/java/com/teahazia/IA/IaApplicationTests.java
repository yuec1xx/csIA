package com.teahazia.IA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IaApplicationTests {

	@Test
	void contextLoads() {
	}

}
