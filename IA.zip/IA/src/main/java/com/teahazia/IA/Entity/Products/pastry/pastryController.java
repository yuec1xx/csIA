package com.teahazia.IA.Entity.Products.pastry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products/pastry")
public class pastryController {
    @Autowired
    private pastryService pastryService;
}
