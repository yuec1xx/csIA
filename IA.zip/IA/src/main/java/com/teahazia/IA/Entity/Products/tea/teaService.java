package com.teahazia.IA.Entity.Products.tea;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class teaService {
    @Autowired
    private teaRepository teaRepository;

    public Tea createTea(String productName, int productPrice, String productType, Boolean available, String productDescription, int totalSales, String teaType, String placeOfOrigin, String teaStrength, int waterTempInCelsius, int steepingTimeInMinutes){

        return teaRepository.save(new Tea(productName,productPrice,productType,available,productDescription,totalSales,teaType,placeOfOrigin,teaStrength,waterTempInCelsius,steepingTimeInMinutes));
    }
}
