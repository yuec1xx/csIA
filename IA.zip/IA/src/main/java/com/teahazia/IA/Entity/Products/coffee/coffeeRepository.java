package com.teahazia.IA.Entity.Products.coffee;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface coffeeRepository extends JpaRepository<Coffee,Long> {
}
