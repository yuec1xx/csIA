package com.teahazia.IA.Authentication;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegistrationRequest {

    @NotNull
    private String name;
    @NotBlank
    private String password;
    @NotBlank
    private String email;
    @NotBlank
    private String role;

    private List<Long> favouriteProducts; // Specific to customers

    private List<ObjectId> myOrders; // Specific to customers

}
