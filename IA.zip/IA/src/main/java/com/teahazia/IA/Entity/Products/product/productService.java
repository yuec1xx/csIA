package com.teahazia.IA.Entity.Products.product;

import com.mongodb.client.result.UpdateResult;
import com.teahazia.IA.Entity.Products.coffee.Coffee;
import com.teahazia.IA.Entity.Products.coffee.CoffeeDTO;
import com.teahazia.IA.Entity.Products.pastry.Pastry;
import com.teahazia.IA.Entity.Products.pastry.PastryDTO;
import com.teahazia.IA.Entity.Products.tea.Tea;
import com.teahazia.IA.Entity.Products.tea.TeaDTO;
import com.teahazia.IA.Entity.user.User;
import com.teahazia.IA.Entity.Products.coffee.coffeeRepository;
import com.teahazia.IA.Entity.Products.pastry.pastryRepository;
import com.teahazia.IA.Entity.Products.tea.teaRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class productService {
    @Autowired
    private productRepository productRepository;
    @Autowired
    private coffeeRepository coffeeRepository;
    @Autowired
    private teaRepository teaRepository;
    @Autowired
    private pastryRepository pastryRepository;
    @Autowired
    private MongoTemplate mongoTemplate;


    public List<ProductBrief> allProductBriefs() { // return menu info of all products
        List<Product> products = productRepository.findAll();
        return mapProductListToBriefs(products);
    }

    // ------------ view single Product ------------

    public Optional<Product> singleProduct(Long productId){ // Optional in case returned null as no results found
        return productRepository.findById(productId);
    }

    public Optional<ProductDTO> singleProductDTO(Long productId) {
        return productRepository.findById(productId)
                .map(product -> {
                    if (product instanceof Coffee) {
                        return mapCoffeeToDTO((Coffee) product);
                    } else if (product instanceof Tea) {
                        return mapTeaToDTO((Tea) product);
                    } else if (product instanceof Pastry) {
                        return mapPastryToDTO((Pastry) product);
                    } else {
                        // Handle other product types or throw an exception if needed
                        throw new IllegalArgumentException("Unknown product type: " + product.getClass().getSimpleName());
                    }
                });
    }

    public List<ProductBrief> filterSortAndSearchProducts(
            String productType,
            Boolean available,
            Integer minPrice,
            Integer maxPrice,
            String sortBy,
            String search
    ) {
        List<Product> products;

        if (search != null && !search.isEmpty()) {
            String searchLowerCase = search.toLowerCase();
            products = productRepository.findByProductNameContainsIgnoreCase(searchLowerCase);
        } else {
            products = productRepository.findAll();
        }

        if (productType != null) {
            products = products.stream()
                    .filter(product -> product.getProductType().equalsIgnoreCase(productType))
                    .collect(Collectors.toList());
        }

        if (available != null) {
            products = products.stream()
                    .filter(product -> product.getAvailable().equals(available))
                    .collect(Collectors.toList());
        }

        if (minPrice != null && maxPrice != null) {
            products = products.stream()
                    .filter(product -> product.getProductPrice() >= minPrice && product.getProductPrice() <= maxPrice)
                    .collect(Collectors.toList());
        }

        // applying sorting to the filtered list of products
        if (sortBy != null) {
            switch (sortBy) {
                case "name":
                    selectionSort(products, Comparator.comparing(Product::getProductName));
                    // Tell the comparator to base its comparisons on the name of each product in the list
                    break;
                case "sales":
                    selectionSort(products, Comparator.comparingInt(Product::getTotalSales).reversed());
                    // Tell the comparator to base its comparisons on the total sales of each product in the list
                    // Reversed to have descending sales
                    break;
                default:
                    // Default sorting by date
                    selectionSort(products, Comparator.comparing(Product::getProductId));
                    // Tell the comparator to base its comparisons on the id of each product in the list
                    // Smaller productId = created earlier
                    break;
            }
        }
        return mapProductListToBriefs(products);
    }

    // Selection Sort
    // Take in a list of products and a comparator
    public static void selectionSort(List<Product> products, Comparator<Product> comparator) {
        int n = products.size(); // Get the total number of product
        for (int i = 0; i < n - 1; i++) { // loop through each index position of the list, starting from the first
            int minIndex = i; // assume current index's value as minimum
            for (int j = i + 1; j < n; j++) { // loop through the remaining part of the list, excluding current position and prior
                if (comparator.compare(products.get(j), products.get(minIndex)) < 0) {
                    // the compare method of the comparator class returns negative value if value at index 0 is less than index 1
                    // If the product at index j is smaller than the product at minIndex, update minIndex
                    minIndex = j;
                }
            }
            // Swap the products at the current index (i) and the index with the smallest value found in the remaining of the list
            Collections.swap(products, i, minIndex);
        }
    }

    // ------------ Products & Favourite List ------------

    public String addProductToFavourite(Long productId, ObjectId customerId){
        mongoTemplate.update(User.class) // Update the `User` document using `mongoTemplate`
                .matching(Criteria.where("id").is(customerId)) // Find the customer document by matching the `customerId`
                .apply(new Update().push("favouriteProducts").value(productId)) // Apply an update to push the `product` into the `favourite` field (association)
                .first(); // Ensure that only one customer document is updated
        return "Product added to favourite!";
    }

    public String removeProductFromFavourite(Long productId, ObjectId customerId) {
        UpdateResult updateResult = mongoTemplate.update(User.class)
                .matching(Criteria.where("id").is(customerId))
                .apply(new Update().pull("favouriteProducts", productId))
                .first();
        if (updateResult.getModifiedCount() > 0) {
            return "Product removed from the favorite list!";
        } else {
            return "Product not found in the favorite list.";
        }
    }


    // ------------ DTO mappings ------------

    public ProductDTO mapSingleProductToDTO(Product product) {
        if (product instanceof Coffee) {
            return mapCoffeeToDTO((Coffee) product);
        } else if (product instanceof Tea) {
            return mapTeaToDTO((Tea) product);
        } else if (product instanceof Pastry) {
            return mapPastryToDTO((Pastry) product);
        } else {
            // Handle other product types or throw an exception if needed
            throw new IllegalArgumentException("Unknown product type: " + product.getClass().getSimpleName());
        }
    }

    private List<ProductBrief> mapProductListToBriefs(List<Product> products) {
        return products.stream()
                .map(product -> new ProductBrief(product.getProductName(), product.getProductPrice()))
                .collect(Collectors.toList());
    }

    private ProductDTO mapCoffeeToDTO(Coffee product){
        return new CoffeeDTO(product.getProductId(), product.getProductName(), product.getProductPrice(), product.getProductType(), product.getAvailable(), product.getProductDescription(),
                product.getMilkAvailable(),
                product.getCoffeeTemp(),
                product.getCoffeeStrength());
    }

    private ProductDTO mapTeaToDTO(Tea product){
        return new TeaDTO(product.getProductId(), product.getProductName(), product.getProductPrice(), product.getProductType(), product.getAvailable(), product.getProductDescription(),
                product.getTeaType(),
                product.getPlaceOfOrigin(),
                product.getTeaStrength(),
                product.getWaterTempInCelsius(),
                product.getSteepingTimeInMinutes());
    }

    private ProductDTO mapPastryToDTO(Pastry product) {
        return new PastryDTO(product.getProductId(), product.getProductName(), product.getProductPrice(), product.getProductType(), product.getAvailable(), product.getProductDescription(),
                product.isGlutenFree(),
                product.getSweetness(),
                product.getFlavors() );
    }



    public boolean isProductExists(String productName) {
        return (productRepository.findByProductNameIgnoreCase(productName).isPresent());
    }

    /*
    public List<Product> allProducts(){
        return productRepository.findAll();
    } // return the complete info of all product stored

    public List<Product> availableProducts(){
        return productRepository.findByAvailableTrue();
    } // return the complete info of all available products

    public List<Product> unavailableProducts(){
        return productRepository.findByAvailableFalse();
    } // return the complete info of all not available products

    public List<Product> productsByType(String productType){
        return productRepository.findByProductType(productType);
    }

    public List<Product> getProductsInPriceRange(int minPrice, int maxPrice) {
        return productRepository.findByProductPriceBetween(minPrice, maxPrice);
    }

    private List<ProductDTO> mapProductListToDTOs(List<Product> products){
        return products.stream()
                .map(product -> {
                    if (product instanceof Coffee) {
                        return mapCoffeeToDTO((Coffee) product);
                    } else if (product instanceof Tea) {
                        return mapTeaToDTO((Tea) product);
                    } else if (product instanceof Pastry) {
                        return mapPastryToDTO((Pastry) product);
                    } else {
                        // Handle other product types or throw an exception if needed
                        throw new IllegalArgumentException("Unknown product type: " + product.getClass().getSimpleName());
                    }
                })
                .collect(Collectors.toList());
    }

     */


}
