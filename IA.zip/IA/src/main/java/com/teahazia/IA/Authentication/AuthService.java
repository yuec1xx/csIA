package com.teahazia.IA.Authentication;

import com.teahazia.IA.Config.JwtService;
import com.teahazia.IA.Config.jwtUserDetailsService;
import com.teahazia.IA.Entity.user.User;
import com.teahazia.IA.Entity.user.userRepository;
import io.micrometer.common.util.StringUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
@RequiredArgsConstructor
public class AuthService {
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private userRepository userRepository;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private jwtUserDetailsService jwtUserDetailsService;


    public AuthResponse register(RegistrationRequest request) {
        try {
            // Validate request parameters
            if (StringUtils.isEmpty(request.getName()) || StringUtils.isEmpty(request.getEmail()) || StringUtils.isEmpty(request.getPassword())) {
                // Return a bad request response if any of the required fields is empty
                return AuthResponse.builder()
                        .error("Incomplete registration data")
                        .build();
            }

            // check email format

            // Check if a user with the same email already exists
            if (userRepository.findByEmail(request.getEmail()).isPresent()) {
                return AuthResponse.builder()
                        .error("Email already registered")
                        .build();
            }

            var user = User.builder()
                    .name(request.getName())
                    .email(request.getEmail())
                    .password(passwordEncoder.encode(request.getPassword())) // hash
                    .role("Customer")
                    .favouriteProducts(new ArrayList<>())
                    .myOrders(new ArrayList<>())
                    .cart(new ArrayList<>())
                    .build();

            // Save the user to the repository
            userRepository.save(user);

            // Generate a JWT token
            var userDetails = jwtUserDetailsService.loadUserByUsername(user.getEmail());
            var jwtToken = jwtService.generateToken(userDetails);

            // Return a successful response with the JWT token
            return AuthResponse.builder()
                    .accessToken(jwtToken)
                    .build();
        } catch (Exception e) {
            // Handle any unexpected exceptions and provide an error response
            throw new RuntimeException("Authentication failed", e);
        }
    }



    public AuthResponse authenticate(AuthRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.getEmail(),
                            request.getPassword()
                    )
            );

            var user = userRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));

            var userDetails = jwtUserDetailsService.loadUserByUsername(user.getEmail());
            var jwtToken = jwtService.generateToken(userDetails);

            return AuthResponse.builder().accessToken(jwtToken).build();
        } catch (AuthenticationException e) {
            // Handle authentication failure (e.g., invalid credentials)
            throw new BadCredentialsException("Invalid username or password", e);
        } catch (Exception e) {
            // Handle other unexpected errors
            throw new RuntimeException("Authentication failed", e);
        }
    }



}
