package com.teahazia.IA.Config;

import com.teahazia.IA.Entity.user.User;
import com.teahazia.IA.Entity.user.userRepository;
import com.teahazia.IA.Config.jwtUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class jwtUserDetailsService implements UserDetailsService { // specifies how to load user information
    @Autowired
    private userRepository userRepository;
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<User> user = userRepository.findByEmail(email);
        return user.map(jwtUserDetails::new).orElseThrow(()->new UsernameNotFoundException("User not found "+email));
    }
}
