package com.teahazia.IA.Entity.order;

import com.mongodb.client.result.UpdateResult;
import com.teahazia.IA.Config.JwtService;
import com.teahazia.IA.Entity.Products.product.ProductBrief;
import com.teahazia.IA.Entity.Products.product.ProductDTO;
import com.teahazia.IA.Entity.user.User;
import com.teahazia.IA.Entity.Products.product.Product;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class orderService {

    @Autowired
    private orderRepository orderRepository;
    @Autowired
    private MongoTemplate mongoTemplate;
    @Autowired
    private com.teahazia.IA.Entity.Products.product.productRepository productRepository;
    @Autowired
    private com.teahazia.IA.Entity.user.userRepository userRepository;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private OrderManager orderManager;


    public productOrder createProductOrder(ProductDTO productDTO, int quantity, String orderCustomization){
        return new productOrder(productDTO,quantity,orderCustomization);
    }

    public String addProductToCart(productOrder productOrder, ObjectId customerId){
        mongoTemplate.update(User.class) // Update the `User` document using `mongoTemplate`
                .matching(Criteria.where("id").is(customerId)) // Find the customer document by matching the `customerId`
                .apply(new Update().push("cart").value(productOrder)) // Apply an update to push the `product` into the `favourite` field (association)
                .first(); // Ensure that only one customer document is updated
        return "Product added to the cart!";
    }

    public String removeProductFromCart(Long productOrderId, ObjectId customerId) {
        UpdateResult result = mongoTemplate.update(User.class)
                .matching(Criteria.where("id").is(customerId))
                .apply(new Update().pull("cart", Query.query(Criteria.where("productOrderId").is(productOrderId))))
                .first();

        if (result.getModifiedCount() > 0) {
            return "Product removed from the cart!";
        } else {
            return "Product not found in the cart.";
        }
    }

    public Order submitOrder(Date orderDate, String orderStatus, int totalCost, List<productOrder> orderContent, ObjectId customerId) {
        Optional<User> userOptional = userRepository.findById(customerId);

        if (userOptional.isPresent()) {
            User customer = userOptional.get();

            // Create an order object with the provided data
            Order order = orderRepository.insert(new Order(orderDate, orderStatus, totalCost, orderContent, customerId));

            // Associate the order with the customer
            mongoTemplate.update(User.class)
                    .matching(Criteria.where("id").is(customerId))
                    .apply(new Update().push("myOrders").value(order))
                    .first();

            return order;
        }

        // Handle the case where the user is not found
        throw new IllegalArgumentException("User not found for customerId: " + customerId);
    }

    public List<Order> allCompletedOrders() { // return menu info of all products
        List<Order> orders = orderRepository.findByOrderStatus("Completed");
        // Sort list of completed orders from earlier to later
        selectionSort(orders, Comparator.comparing(Order::getOrderDate));
        orderManager.setCompletedOrders(orders); // last index (most recent) is the top
        return orderManager.getCompletedOrders();
    }

    public List<Order> allPendingOrders() { // return menu info of all products
        List<Order> orders = orderRepository.findByOrderStatus("Pending");
        // Sort list of completed orders from later to earlier
        selectionSort(orders, Comparator.comparing(Order::getOrderDate).reversed());
        orderManager.setPendingOrders(orders); // last index (upcoming) is on top
        return orderManager.getPendingOrders();
    }

    public Order SingleOrder(ObjectId orderId) { // return menu info of all products
        return orderRepository.findByOrderId(orderId);
    }

    public void markUpcomingOrderAsCompleted() {
        orderManager.markAsCompleted();
    }

    public static void selectionSort(List<Order> orders, Comparator<Order> comparator) { // sort from smaller(older) to larger(newer)
        int n = orders.size();
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (comparator.compare(orders.get(j), orders.get(minIndex)) < 0) {
                    minIndex = j;
                }
            }
            Collections.swap(orders, i, minIndex);
        }
    }


}
