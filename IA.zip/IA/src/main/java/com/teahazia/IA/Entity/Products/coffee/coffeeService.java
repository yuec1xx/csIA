package com.teahazia.IA.Entity.Products.coffee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class coffeeService {
    @Autowired
    private coffeeRepository coffeeRepository;

    public Coffee createCoffee(String productName, int productPrice, String productType, Boolean available, String productDescription, int totalSales, String milkAvailable, String coffeeTemp, int coffeeStrength){

        return coffeeRepository.save(new Coffee(productName,productPrice,productType,available,productDescription,totalSales,milkAvailable,coffeeTemp,coffeeStrength));
    }

}
