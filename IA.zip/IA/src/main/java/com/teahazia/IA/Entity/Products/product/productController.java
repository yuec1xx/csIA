package com.teahazia.IA.Entity.Products.product;

import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvException;
import com.teahazia.IA.Entity.order.orderService;
import com.teahazia.IA.Entity.order.productOrder;
import com.teahazia.IA.Entity.user.CustomerDTO;
import com.teahazia.IA.Entity.user.User;
import com.teahazia.IA.Entity.Products.coffee.Coffee;
import com.teahazia.IA.Entity.Products.coffee.coffeeRepository;
import com.teahazia.IA.Entity.Products.coffee.coffeeService;
import com.teahazia.IA.Entity.Products.pastry.Pastry;
import com.teahazia.IA.Entity.Products.pastry.pastryRepository;
import com.teahazia.IA.Entity.Products.pastry.pastryService;
import com.teahazia.IA.Entity.Products.tea.Tea;
import com.teahazia.IA.Entity.Products.tea.teaRepository;
import com.teahazia.IA.Entity.Products.tea.teaService;
import com.teahazia.IA.Entity.user.userRepository;
import com.teahazia.IA.Entity.user.userService;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.*;
import com.opencsv.CSVReader;

@RestController
@RequestMapping("/products")
public class productController {
    @Autowired
    private productService productService;
    @Autowired
    private coffeeService coffeeService;
    @Autowired
    private teaService teaService;
    @Autowired
    private pastryService pastryService;
    @Autowired
    private productRepository productRepository;
    @Autowired
    private coffeeRepository coffeeRepository;
    @Autowired
    private teaRepository teaRepository;
    @Autowired
    private pastryRepository pastryRepository;
    @Autowired
    private userRepository userRepository;
    @Autowired
    private userService userService;
    @Autowired
    private orderService orderService;


    // ------------ Browse Products ------------

    @GetMapping("/menu") // return menu info of all products
    public ResponseEntity<List<ProductBrief>> getAllProductBriefs() {
        List<ProductBrief> productBriefs = productService.allProductBriefs();
        return new ResponseEntity<>(productBriefs, HttpStatus.OK);
    }

    // ------------ Filter / Sort / Search Products ------------
    @GetMapping("/menu/filter")
    public ResponseEntity<List<ProductBrief>> filterProducts(@RequestParam(required = false) String productType,
                                                             @RequestParam(required = false) Boolean available,
                                                             @RequestParam(required = false) Integer minPrice,
                                                             @RequestParam(required = false) Integer maxPrice,
                                                             @RequestParam(required = false) String sortBy,
                                                             @RequestParam(required = false) String search) {
        List<ProductBrief> productBriefs = productService.filterSortAndSearchProducts(productType, available, minPrice, maxPrice, sortBy, search);
        return new ResponseEntity<>(productBriefs, HttpStatus.OK);
    }

    // ------------ Browse Single Product ------------

    @GetMapping("/menu/{productId}")
    public ResponseEntity<Optional<ProductDTO>> getSingleProductDTO(@PathVariable Long productId) {
        Optional<ProductDTO> productDTOOptional = productService.singleProductDTO(productId);

        // Check if the productDTO is present in the Optional
        if (productDTOOptional.isPresent()) {
            return ResponseEntity.ok(productDTOOptional);
        } else {
            // Return error if the product doesn't exist
            return ResponseEntity.notFound().build();
        }
    }

    // ------------ Favourite ------------
    @PostMapping("/menu/{productId}_mark_favourite")
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<String> markProductAsFavourite(@PathVariable Long productId) {
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));
        if (!customer.getFavouriteProducts().contains(productId)) {
            String result = productService.addProductToFavourite(productId, customer.getId());
            return new ResponseEntity<>(result, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Product is already a favorite.", HttpStatus.OK);
        }
    }

    @DeleteMapping("/menu/{productId}_unmark_favourite")
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<String> removeProductFromFavourite(@PathVariable Long productId) {
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));

        if (customer.getFavouriteProducts().contains(productId)) {
            String result = productService.removeProductFromFavourite(productId, customer.getId());
            return new ResponseEntity<>(result, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Product is not in the favorite list.", HttpStatus.OK);
        }

    }

    // ------------ Add To Cart ------------

    @PostMapping("/menu/{productId}_add_to_cart") // create a productOrder and add it to the cart list
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<String> addToCart(@PathVariable Long productId,// read the product id from th path
                                            @RequestBody Map<String, String> payload) {
        Product product = productRepository.findByProductId(productId).orElseThrow(() -> new IllegalArgumentException("Product not found"));
        ProductDTO productDTO = productService.mapSingleProductToDTO(product);
        int quantity = Integer.parseInt(payload.get("quantity")); // read the selected quantity

        // Determine the product type
        String productType = product.getProductType();

        String orderCustomization = ""; // initialise
        switch (productType) {
            case "Coffee" -> {
                orderCustomization = payload.get("milkAvailable") + ", " + payload.get("coffeeTemp");
            }
            case "Tea" -> {
                orderCustomization = "";
            }
            case "Pastry" -> {
                orderCustomization = payload.get("flavors");
            }
            default -> ResponseEntity.badRequest().build();
        };

        // Get the current user
        String customerEmail = userService.getCurrentAuthenticatedUser();
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));

        // check if the same product already exist in cart
        String finalOrderCustomization = orderCustomization;
        Optional<productOrder> existingProductOrder = customer.getCart().stream() // loop through the existing productOrders in cart (2-dimensional array)
                .filter(order -> order.getProductDTO().equals(productDTO) && order.getOrderCustomization().equals(finalOrderCustomization)) // if the product with the same customization already exist
                .findFirst();

        if (existingProductOrder.isPresent()) {
            // Increment the quantity of the existing productOrder
            existingProductOrder.get().setQuantity(existingProductOrder.get().getQuantity() + 1);
            userRepository.save(customer);
            return new ResponseEntity<>("Product already in cart. We've added one more to the quantity.", HttpStatus.OK);
        } else {
            String result = orderService.addProductToCart(orderService.createProductOrder(productDTO, quantity, orderCustomization), customer.getId());
            return new ResponseEntity<>(result, HttpStatus.OK);
        }

    }

    // ------------ Create Product ------------
    @PostMapping("menu/create")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<String> createProduct(@RequestBody Map<String, String> payload) {
        return createProductFromPayload(payload);
    }

    public ResponseEntity<String> createProductFromPayload(Map<String, String> payload){
        String productType = payload.get("productType");
        String productName = payload.get("productName");

        if (productType == null) {
            return ResponseEntity.badRequest().body("Missing 'productType' in the payload.");
        } else if (productService.isProductExists(productName)) {        // Check if the product with the same name already exists
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Product with name '" + productName + "' already exists.");
        }

        try {
            return switch (productType) {
                case "Coffee" -> {
                    Coffee coffee = createCoffeeFromPayload(payload);
                    yield ResponseEntity.status(HttpStatus.CREATED).body("Coffee created: " + coffee.getProductName());
                }
                case "Tea" -> {
                    Tea tea = createTeaFromPayload(payload);
                    yield ResponseEntity.status(HttpStatus.CREATED).body("Tea created: " + tea.getProductName());
                }
                case "Pastry" -> {
                    Pastry pastry = createPastryFromPayload(payload);
                    yield ResponseEntity.status(HttpStatus.CREATED).body("Pastry created: " + pastry.getProductName());
                }
                default -> ResponseEntity.badRequest().body("Unknown product type: " + productType);
            };
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Invalid payload: " + e.getMessage());
        }
    }

    private Coffee createCoffeeFromPayload(Map<String, String> payload) {
        // Parse the payload map and extract Coffee-specific properties
        String productName = payload.get("productName");
        int productPrice = Integer.parseInt(payload.get("productPrice"));
        boolean available = Boolean.parseBoolean(payload.get("available"));
        String productDescription = payload.get("productDescription");
        int totalSales = Integer.parseInt(payload.get("totalSales"));
        String milkAvailable = payload.get("milkAvailable");
        String coffeeTemp = payload.get("coffeeTemp");
        int coffeeStrength = Integer.parseInt(payload.get("coffeeStrength"));

        // Create and save a Coffee instance
        return coffeeService.createCoffee(productName, productPrice, "Coffee", available,productDescription, totalSales, milkAvailable, coffeeTemp, coffeeStrength);
    }
    private Tea createTeaFromPayload(Map<String, String> payload) {
        String productName = payload.get("productName");
        int productPrice = Integer.parseInt(payload.get("productPrice"));
        boolean available = Boolean.parseBoolean(payload.get("available"));
        String productDescription = payload.get("productDescription");
        int totalSales = Integer.parseInt(payload.get("totalSales"));
        String teaType = payload.get("teaType");
        String placeOfOrigin = payload.get("placeOfOrigin");
        String teaStrength = payload.get("teaStrength");
        int waterTempInCelsius = Integer.parseInt(payload.get("waterTempInCelsius"));
        int steepingTimeInMinutes = Integer.parseInt(payload.get("steepingTimeInMinutes"));
        return teaService.createTea(productName, productPrice, "Tea",available,productDescription,totalSales, teaType,placeOfOrigin,teaStrength,waterTempInCelsius,steepingTimeInMinutes);
    }
    private Pastry createPastryFromPayload(Map<String, String> payload) {
        String productName = payload.get("productName");
        int productPrice = Integer.parseInt(payload.get("productPrice"));
        boolean available = Boolean.parseBoolean(payload.get("available"));
        String productDescription = payload.get("productDescription");
        int totalSales = Integer.parseInt(payload.get("totalSales"));
        boolean glutenFree = Boolean.parseBoolean(payload.get("glutenFree"));
        int sweetness = Integer.parseInt(payload.get("sweetness"));
        String flavors = payload.get("flavors");
        return pastryService.createPastry(productName, productPrice, "Pastry", available, productDescription, totalSales, glutenFree, sweetness, flavors);
    }


    // ------------ Import Products ------------

    @PostMapping("/menu/import")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<String> importProducts(@RequestParam("file") MultipartFile file) {
        try {
            // Check if the uploaded file is not empty
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("Uploaded file is empty.");
            }

            // Parse the file, iterate through products, and map data to payload
            List<Map<String, String>> productsData = parseFile(file);

            // Import products one by one
            StringBuilder successSummary = new StringBuilder("Products imported successfully.\n");
            StringBuilder errorSummary = new StringBuilder("Error importing products:\n");

            for (Map<String, String> productPayload : productsData) {
                try {
                    createProductFromPayload(productPayload);
                    successSummary.append("Product imported: ").append(productPayload.get("productName")).append("\n");
                } catch (Exception e) {
                    // Handle specific exceptions if needed
                    errorSummary.append("Failed to import product: ").append(productPayload.get("productName")).append(", Error: ").append(e.getMessage()).append("\n");
                }
            }

            if (errorSummary.length() > "Error importing products:\n".length()) {
                // There were errors during import
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorSummary.toString());
            } else {
                // All products imported successfully
                return ResponseEntity.ok(successSummary.toString());
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error importing products: " + e.getMessage());
        }
    }


    private List<Map<String, String>> parseFile(MultipartFile file) throws IOException, CsvException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
             // set up BufferedReader to read the content of the file, InputStreamReader convert file to character stream
             CSVReader csvReader = new CSVReaderBuilder(reader).withSkipLines(3).build()) {
            // skip the first 3 lines as they contain column names and not actual data
            List<String[]> rows;
            try {
                rows = csvReader.readAll(); // reads all remaining lines of the CSV file into a list of string arrays
            } catch (CsvException e) {
                throw new IOException("Error reading CSV file: " + e.getMessage(), e);
            }

            List<Map<String, String>> productsData = new ArrayList<>(); // initializes empty list to store the parsed data

            for (String[] row : rows) {
                try {
                    if (row.length >= 9) {
                        String productType = row[2];
                        Map<String, String> payload = new HashMap<>();
                        payload.put("productName", row[0]);
                        payload.put("productPrice", row[1]);
                        payload.put("productType", row[2]);
                        payload.put("available", row[3]);
                        payload.put("productDescription", row[4]);
                        payload.put("totalSales", row[5]);

                        if ("Coffee".equals(productType)) {
                            payload.put("milkAvailable", row[6]);
                            payload.put("coffeeTemp", row[7]);
                            payload.put("coffeeStrength", row[8]);
                        } else if ("Tea".equals(productType)) {
                            payload.put("teaType", row[6]);
                            payload.put("placeOfOrigin", row[7]);
                            payload.put("teaStrength", row[8]);
                            payload.put("waterTempInCelsius", row[9]);
                            payload.put("steepingTimeInMinutes", row[10]);
                        } else if ("Pastry".equals(productType)) {
                            payload.put("glutenFree", row[6]);
                            payload.put("sweetness", row[7]);
                            payload.put("flavors", row[8]);
                        }
                        // Add additional columns as needed
                        productsData.add(payload);
                    }
                } catch (ArrayIndexOutOfBoundsException e) {
                    // Handle the case where a row doesn't have enough columns
                    throw new IOException("Error parsing CSV row: Insufficient columns", e);
                }
            }

            return productsData;
        }
    }


    // ------------ Update Products ------------

    @GetMapping("/menu/{productId}/admin")
    @PreAuthorize("hasAuthority('Owner')") // Admin page access
    public ResponseEntity<Optional<Product>> getSingleProduct(@PathVariable Long productId){
        return new ResponseEntity<>(productService.singleProduct(productId), HttpStatus.OK);
    }

    @PutMapping("menu/{productId}/admin/save_changes")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<String> updateProduct(@PathVariable Long productId, @RequestBody Map<String, String> payload) {
        Optional<Product> productOptional = productRepository.findByProductId(productId);

        if (productOptional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Product product = productOptional.get();
        String productType = payload.get("productType");

        if (productType == null) {
            return ResponseEntity.badRequest().body("Missing 'productType' in the payload.");
        }

        try {
            return switch (productType) {
                case "Coffee" -> {
                    Coffee coffee = updateCoffee((Coffee) product, payload);
                    yield ResponseEntity.status(HttpStatus.CREATED).body("Coffee updated: " + coffee.getProductName());
                }
                case "Tea" -> {
                    Tea tea = updateTea((Tea) product, payload);
                    yield ResponseEntity.status(HttpStatus.CREATED).body("Tea updated: " + tea.getProductName());
                }
                case "Pastry" -> {
                    Pastry pastry = updatePastry((Pastry) product, payload);
                    yield ResponseEntity.status(HttpStatus.CREATED).body("Pastry updated: " + pastry.getProductName());
                }
                default -> ResponseEntity.badRequest().body("Unknown product type: " + productType);
            };
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Invalid payload: " + e.getMessage());
        }
    }

    private Coffee updateCoffee(Coffee coffee, Map<String, String> payload) {
        try{
            coffee.setProductName(payload.get("productName"));
            coffee.setProductPrice(Integer.parseInt(payload.get("productPrice")));
            coffee.setAvailable(Boolean.parseBoolean(payload.get("available")));
            coffee.setProductDescription(payload.get("productDescription"));
            coffee.setTotalSales(Integer.parseInt(payload.get("totalSales")));
            coffee.setMilkAvailable(payload.get("milkAvailable"));
            coffee.setCoffeeTemp(payload.get("coffeeTemp"));
            coffee.setCoffeeStrength(Integer.parseInt(payload.get("coffeeStrength")));

            return coffeeRepository.save(coffee);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid numeric value in the payload.");
        } catch (Exception e) {
            throw new RuntimeException("An error occurred while updating the product.", e);
        }
    }

    private Tea updateTea(Tea tea, Map<String, String> payload) {
        try{
            // Parse the payload map and extract Coffee-specific properties
            tea.setProductName(payload.get("productName"));
            tea.setProductPrice(Integer.parseInt(payload.get("productPrice")));
            tea.setAvailable(Boolean.parseBoolean(payload.get("available")));
            tea.setProductDescription(payload.get("productDescription"));
            tea.setTotalSales(Integer.parseInt(payload.get("totalSales")));
            tea.setTeaType(payload.get("teaType"));
            tea.setPlaceOfOrigin(payload.get("placeOfOrigin"));
            tea.setTeaStrength(payload.get("teaStrength"));
            tea.setWaterTempInCelsius(Integer.parseInt(payload.get("waterTempInCelsius")));
            tea.setSteepingTimeInMinutes(Integer.parseInt(payload.get("steepingTimeInMinutes")));

            return teaRepository.save(tea);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid numeric value in the payload.");
        } catch (Exception e) {
            throw new RuntimeException("An error occurred while updating the coffee.", e);
        }
    }

    private Pastry updatePastry(Pastry pastry, Map<String, String> payload) {
        try{
            pastry.setProductName(payload.get("productName"));
            pastry.setProductPrice(Integer.parseInt(payload.get("productPrice")));
            pastry.setAvailable(Boolean.parseBoolean(payload.get("available")));
            pastry.setProductDescription(payload.get("productDescription"));
            pastry.setTotalSales(Integer.parseInt(payload.get("totalSales")));
            pastry.setGlutenFree(Boolean.parseBoolean(payload.get("glutenFree")));
            pastry.setSweetness(Integer.parseInt(payload.get("sweetness")));
            pastry.setFlavors(payload.get("flavors"));

            return pastryRepository.save(pastry);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid numeric value in the payload.");
        } catch (Exception e) {
            throw new RuntimeException("An error occurred while updating the coffee.", e);
        }
    }


    // ------------ Delete Products ------------

    @DeleteMapping("/menu/{productId}/admin/delete")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<String> deleteProduct(@PathVariable Long productId) {
        Optional<Product> productOptional = productRepository.findByProductId(productId);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();

            // Delete the product
            productRepository.delete(product);

            return ResponseEntity.ok(product.getProductName() + " deleted.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }






    /*
    @GetMapping // return complete info of all products
    @PreAuthorize("hasAuthority('Owner')") // Admin page access
    public ResponseEntity<List<Product>> getProducts(){
        return new ResponseEntity<>(productService.allProducts(), HttpStatus.OK);
    }

    @GetMapping("/available") // return complete info of available products
    @PreAuthorize("hasAuthority('Owner')") // Admin page access
    public ResponseEntity<List<Product>> getAvailableProducts(){
        return new ResponseEntity<>(productService.availableProducts(), HttpStatus.OK);
    }

    @GetMapping("/unavailable") // return complete info of unavailable products
    @PreAuthorize("hasAuthority('Owner')") // Admin page access
    public ResponseEntity<List<Product>> getUnavailableProducts(){
        return new ResponseEntity<>((productService.unavailableProducts()), HttpStatus.OK);
    }

    @GetMapping("/type/{productType}") // return complete info of all products of one type
    @PreAuthorize("hasAuthority('Owner')") // Admin page access
    public ResponseEntity<List<Product>> getProductsByType(@PathVariable String productType){
        return new ResponseEntity<>(productService.productsByType(productType), HttpStatus.OK);
    }

    @GetMapping("/price-range")
    @PreAuthorize("hasAuthority('Owner')") // Admin page access
    public ResponseEntity<List<Product>> getProductsInPriceRange(
            @RequestParam int minPrice,
            @RequestParam int maxPrice) {
        return new ResponseEntity<>(productService.getProductsInPriceRange(minPrice, maxPrice), HttpStatus.OK);
    }

    */




}
