package com.teahazia.IA.Entity.Products.pastry;

import com.teahazia.IA.Entity.Products.product.ProductDTO;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PastryDTO extends ProductDTO {
    private boolean glutenFree;
    private int sweetness;
    private String flavors;

    public PastryDTO(Long productId, String productName, int productPrice, String productType, Boolean available, String productDescription, boolean glutenFree, int sweetness, String flavors) {
        super(productId, productName, productPrice, productType, available, productDescription);
        this.glutenFree = glutenFree;
        this.sweetness = sweetness;
        this.flavors = flavors;
    }
}
