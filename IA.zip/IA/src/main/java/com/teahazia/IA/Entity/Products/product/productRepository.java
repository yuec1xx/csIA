package com.teahazia.IA.Entity.Products.product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface productRepository extends JpaRepository<Product,Long> {
    @Query("select p from Product p where upper(p.productName) like upper(concat('%', ?1, '%'))")
    List<Product> findByProductNameContainsIgnoreCase(@Nullable String productName);
    @Query("select p from Product p where p.productPrice between ?1 and ?2")
    List<Product> findByProductPriceBetween(int productPriceStart, int productPriceEnd);
    @Query("select p from Product p where p.available = false")
    List<Product> findByAvailableFalse();
    List<Product> findByProductTypeAndAvailable(String productType, Boolean available);
    List<Product> findByProductType(String productType);
    List<Product> findByAvailableTrue();
    Optional<Product> findByProductId(Long productId);

    Optional<Object> findByProductNameIgnoreCase(String productName);
}
