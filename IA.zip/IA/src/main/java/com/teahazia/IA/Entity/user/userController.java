package com.teahazia.IA.Entity.user;

import com.teahazia.IA.Entity.Products.coffee.Coffee;
import com.teahazia.IA.Entity.Products.pastry.Pastry;
import com.teahazia.IA.Entity.Products.product.ProductDTO;
import com.teahazia.IA.Entity.Products.product.productRepository;
import com.teahazia.IA.Entity.Products.tea.Tea;
import com.teahazia.IA.Entity.order.Order;
import com.teahazia.IA.Entity.Products.product.Product;
import com.teahazia.IA.Entity.order.orderController;
import com.teahazia.IA.Entity.order.orderService;
import com.teahazia.IA.Entity.order.productOrder;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping
public class userController {
    @Autowired
    private userService userService;
    @Autowired
    private productRepository productRepository;
    @Autowired
    private userRepository userRepository;
    @Autowired
    private orderService orderService;
    @Autowired
    private orderController orderController;


    @GetMapping("/profile") // return the info of customer's own profile page
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<User> customerProfile(){
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));
        return new ResponseEntity<>(customer,HttpStatus.OK);
    }

    // ------------ Favourite List ------------
    @GetMapping("/profile/favourites") // return customer's favourite product list
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<List<Product>> getFavouriteProducts(){
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));
        List<Long> favoriteProductIds = customer.getFavouriteProducts();
        return new ResponseEntity<>(userService.getFavoriteProducts(favoriteProductIds),HttpStatus.OK);
    }

    // ------------ Order ------------

    @GetMapping("/profile/my_orders") // return all the orders by the customer
    public ResponseEntity<List<Order>> getCustomerOrders(){
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));

        return new ResponseEntity<>(customer.getMyOrders(), HttpStatus.OK);
    }

    @GetMapping("/profile/my_orders/filter")
    public ResponseEntity<List<Order>> getCustomerOrdersByStatus(@RequestParam String orderStatus) {
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        List<Order> filteredOrders = customer.getMyOrders().stream()
                .filter(order -> order.getOrderStatus().equalsIgnoreCase(orderStatus))
                .collect(Collectors.toList());

        return new ResponseEntity<>(filteredOrders, HttpStatus.OK);
    }

    @GetMapping("/profile/my_orders/{orderId}") // return all the orders by the customer
    public ResponseEntity<Order> getSingleCustomerOrder(@PathVariable ObjectId orderId){
        return new ResponseEntity<>(orderService.SingleOrder(orderId), HttpStatus.OK);
    }

    @DeleteMapping("/profile/my_orders/{orderId}/cancel")
    public ResponseEntity<String> cancelCustomerOrder(
            @PathVariable ObjectId orderId,
            @RequestBody Map<String, String> requestBody) {
        return orderController.cancelOrderById(orderId, requestBody);
    }


    // ------------ Cart ------------
    @GetMapping("/cart") // return customer's cart
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<List<productOrder>> getCart(){
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));
        return new ResponseEntity<>(customer.getCart(),HttpStatus.OK);
    }

    @GetMapping("/cart/{productOrderId}") // return one item in cart
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<productOrder> getProductFromCart(@PathVariable Long productOrderId) {
        String customerEmail = userService.getCurrentAuthenticatedUser(); // identify current user
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));

        // Find the productOrder in the cart with the specified productId
        Optional<productOrder> matchingProductOrder = customer.getCart().stream()
                .filter(order -> order.getProductOrderId().equals(productOrderId))
                .findFirst();

        return matchingProductOrder
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/cart/{productOrderId}/edit")
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<String> editProductFromCart(@PathVariable Long productOrderId,
                                                      @RequestBody Map<String, String> payload) {

        String customerEmail = userService.getCurrentAuthenticatedUser();
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));

        // Find the productOrder in the cart with the specified id
        productOrder productOrder = customer.getCart().stream()
                .filter(order -> order.getProductOrderId().equals(productOrderId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        // Update common fields for all product types
        productOrder.setQuantity(Integer.parseInt(payload.get("quantity")));

        // Update product-specific fields based on the product type
        ProductDTO productDTO = productOrder.getProductDTO();
        switch (productDTO.getProductType()) {
            case "Coffee":
                productOrder.setOrderCustomization(payload.get("milkAvailable") + ", " + payload.get("coffeeTemp"));
                break;
            case "Tea":
                // No additional customization for Tea
                break;
            case "Pastry":
                productOrder.setOrderCustomization(payload.get("flavors"));
                break;
            default:
                return ResponseEntity.badRequest().body("Invalid product type");
        }

        // Save the updated user
        userRepository.save(customer);

        return ResponseEntity.status(HttpStatus.CREATED).body("Cart updated: " + productDTO.getProductName());
    }


    @DeleteMapping("/cart/{productOrderId}/remove")
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<String> removeProductFromCart(@PathVariable Long productOrderId) {
        String customerEmail = userService.getCurrentAuthenticatedUser();
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));

        String result = orderService.removeProductFromCart(productOrderId, customer.getId());

        return new ResponseEntity<>(result, HttpStatus.OK);
    }


}
