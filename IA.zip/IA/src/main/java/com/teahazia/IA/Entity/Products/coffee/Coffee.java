package com.teahazia.IA.Entity.Products.coffee;

// mySQL Hibernate annotation

import com.teahazia.IA.Entity.Products.product.Product;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@PrimaryKeyJoinColumn(name = "productId")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Coffee extends Product {
    @Column(nullable = false)
    private String milkAvailable;

    @Column(nullable = false)
    private String coffeeTemp;

    @Column(nullable = false)
    private int coffeeStrength;


    public Coffee(String productName, int productPrice, String productType, Boolean available, String productDescription, int totalSales, String milkAvailable, String coffeeTemp, int coffeeStrength) {
        super(productName, productPrice, productType, available, productDescription, totalSales);
        this.milkAvailable = milkAvailable;
        this.coffeeTemp = coffeeTemp;
        this.coffeeStrength = coffeeStrength;
    }
}
