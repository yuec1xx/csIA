package com.teahazia.IA.Entity.order;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface orderRepository extends MongoRepository<Order, ObjectId> {
    Order findByOrderId(ObjectId orderId);
    List<Order> findByOrderStatus(String orderStatus);
    Optional<Order> findByOrderIdAndOrderStatusIgnoreCase(ObjectId orderId, String orderStatus);
    List<Order> findByOrderStatusIgnoreCase(String orderStatus);
    Optional<Order> findByCustomerId(ObjectId customerId);

}
