package com.teahazia.IA.Entity.Products.tea;

import com.teahazia.IA.Entity.Products.product.ProductDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeaDTO extends ProductDTO {
    private String teaType;
    private String placeOfOrigin;
    private String teaStrength;
    private int waterTempInCelsius;
    private int steepingTimeInMinutes;

    public TeaDTO(Long productId, String productName, int productPrice, String productType, Boolean available, String productDescription, String teaType, String placeOfOrigin, String teaStrength, int waterTempInCelsius, int steepingTimeInMinutes) {
        super(productId, productName, productPrice, productType, available, productDescription);
        this.teaType = teaType;
        this.placeOfOrigin = placeOfOrigin;
        this.teaStrength = teaStrength;
        this.waterTempInCelsius = waterTempInCelsius;
        this.steepingTimeInMinutes = steepingTimeInMinutes;
    }
}
