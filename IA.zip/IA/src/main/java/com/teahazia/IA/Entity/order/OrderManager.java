package com.teahazia.IA.Entity.order;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.NoSuchElementException;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class OrderManager {
    private List<Order> pendingOrders;
    private List<Order> completedOrders;

    // Push method to add an element to the top of the stack
    // use the last index as the top
    public void push(List<Order> stack, Order order) {
        stack.add(order);
    }

    // Pop method to remove and return the element from the top of the stack
    public Order pop(List<Order> stack) {
        if (!stack.isEmpty()) {
            return stack.remove(stack.size() - 1); // remove items from the top
        } else {
            throw new NoSuchElementException("No pending orders to mark as completed.");
        }
    }

    public void markAsCompleted() {
        if (!pendingOrders.isEmpty()) {
            Order completedOrder = pop(pendingOrders);
            push(completedOrders, completedOrder);
            System.out.println("Order marked as completed: " + completedOrder);
        } else {
            System.out.println("No pending orders to mark as completed.");
        }
    }

}

