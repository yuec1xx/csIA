package com.teahazia.IA.Entity.Products.tea;

// mySQL Hibernate annotation

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.PrimaryKeyJoinColumn;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.teahazia.IA.Entity.Products.product.Product;


@Entity
@PrimaryKeyJoinColumn(name = "productId")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Tea extends Product {
    @Column(nullable = false)
    private String teaType;

    @Column(nullable = false)
    private String placeOfOrigin;

    @Column(nullable = false)
    private String teaStrength;

    @Column(nullable = false)
    private int waterTempInCelsius;

    @Column(nullable = false)
    private int steepingTimeInMinutes;

    public Tea(String productName, int productPrice, String productType, Boolean available, String productDescription, int totalSales, String teaType, String placeOfOrigin, String teaStrength, int waterTempInCelsius, int steepingTimeInMinutes) {
        super(productName, productPrice, productType, available, productDescription, totalSales);
        this.teaType = teaType;
        this.placeOfOrigin = placeOfOrigin;
        this.teaStrength = teaStrength;
        this.waterTempInCelsius = waterTempInCelsius;
        this.steepingTimeInMinutes = steepingTimeInMinutes;
    }
}
