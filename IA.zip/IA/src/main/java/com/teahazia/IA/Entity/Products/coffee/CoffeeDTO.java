package com.teahazia.IA.Entity.Products.coffee;

import com.teahazia.IA.Entity.Products.product.ProductDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CoffeeDTO extends ProductDTO {
    private String milkAvailable;
    private String coffeeTemp;
    private int coffeeStrength;

    public CoffeeDTO(Long productId, String productName, int productPrice, String productType, Boolean available, String productDescription, String milkAvailable, String coffeeTemp, int coffeeStrength) {
        super(productId, productName, productPrice, productType, available, productDescription);
        this.milkAvailable = milkAvailable;
        this.coffeeTemp = coffeeTemp;
        this.coffeeStrength = coffeeStrength;
    }
}
