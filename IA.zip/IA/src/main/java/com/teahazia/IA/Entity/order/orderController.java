package com.teahazia.IA.Entity.order;

import com.teahazia.IA.Email.EmailService;
import com.teahazia.IA.Entity.Products.product.*;
import com.teahazia.IA.Entity.user.User;
import com.teahazia.IA.Entity.user.userService;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping
public class orderController {
    @Autowired
    private orderService orderService;
    @Autowired
    private orderRepository orderRepository;
    @Autowired
    private productRepository productRepository;
    @Autowired
    private User user;
    @Autowired
    private userService userService;
    @Autowired
    private productService productService;
    @Autowired
    private com.teahazia.IA.Entity.user.userRepository userRepository;
    @Autowired
    private EmailService emailService;


    // ------------ Submit Order ------------

    @PostMapping("/cart/submit_order")
    @PreAuthorize("hasAuthority('Customer')")
    public ResponseEntity<Order> submitOrder(@RequestBody Map<String, Object> payload) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        formatter.setTimeZone(TimeZone.getTimeZone("UTC+2"));

        String dateInString = payload.get("orderDate").toString();
        Date orderDate = formatter.parse(dateInString);
        String orderStatus = payload.get("orderStatus").toString();

        String customerEmail = userService.getCurrentAuthenticatedUser();
        User customer = userRepository.findByEmail(customerEmail).orElseThrow(() -> new IllegalArgumentException("User not found"));

        List<productOrder> orderContent = customer.getCart();

        // Calculate total cost
        int totalCost = calculateTotalCost(orderContent);

        // Loop through orderContent to update totalSales for each product
        for (productOrder order : orderContent) {
            Product product = productRepository.findByProductId(order.getProductDTO().getProductId()).orElseThrow(()-> new IllegalArgumentException("Product not found"));
            product.setTotalSales(product.getTotalSales() + order.getQuantity());
        }

        // Clear the customer's cart
        customer.getCart().clear();

        // Save the updated customer information to the database
        userRepository.save(customer);

        // Submit the order
        ObjectId customerId = customer.getId();
        Order order = orderService.submitOrder(orderDate, orderStatus, totalCost, orderContent, customerId);

        return new ResponseEntity<>(order, HttpStatus.OK);
    }

    public int calculateTotalCost(List<productOrder> cart) {
        return cart.stream()
                .mapToInt(item -> item.getProductDTO().getProductPrice() * item.getQuantity())
                .sum();
    }

    // ------------ Browse Order ------------

    @GetMapping("/order/completed")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<List<Order>> getAllCompletedOrders() {
        return new ResponseEntity<>(orderService.allCompletedOrders(), HttpStatus.OK);
    }

    @GetMapping("/order/completed/{orderId}")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<Order> getSingleCompletedOrder(@PathVariable ObjectId orderId) {
        return new ResponseEntity<>(orderService.SingleOrder(orderId), HttpStatus.OK);
    }

    @GetMapping("/order/pending")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<List<Order>> getAllPendingOrders() {
        return new ResponseEntity<>(orderService.allPendingOrders(), HttpStatus.OK);
    }

    @PutMapping("/order/pending/mark_done")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<String> editOrderStatus(@PathVariable ObjectId orderId, @RequestBody Map<String, String> payload) {
        orderService.markUpcomingOrderAsCompleted();
        return new ResponseEntity<>("Next pending order marked as completed.", HttpStatus.OK);
    }

    @GetMapping("/order/pending/{orderId}")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<Order> getSinglePendingOrder(@PathVariable ObjectId orderId) {
        return new ResponseEntity<>(orderService.SingleOrder(orderId), HttpStatus.OK);
    }

    @DeleteMapping("/order/pending/{orderId}/cancel")
    @PreAuthorize("hasAuthority('Owner')")
    public ResponseEntity<String> cancelOrder(
            @PathVariable ObjectId orderId,
            @RequestBody Map<String, String> requestBody) {
        return cancelOrderById(orderId, requestBody);
    }

    public ResponseEntity<String> cancelOrderById(ObjectId orderId, Map<String, String> requestBody) {
        Optional<Order> orderOptional = orderRepository.findById(orderId);

        if (orderOptional.isPresent()) {
            Order order = orderOptional.get();

            if (requestBody.containsKey("cancellationReason")) {
                String cancellationReason = requestBody.get("cancellationReason");

                // Send the cancellation reason via email (pseudocode)
                sendCancellationEmail(order, cancellationReason);

                for (productOrder productOrder : order.getOrderContent()) {
                    Product product = productRepository.findByProductId(productOrder.getProductDTO().getProductId()).orElseThrow(()-> new IllegalArgumentException("Product not found"));
                    product.setTotalSales(product.getTotalSales() - productOrder.getQuantity());
                }

                // Delete the product
                orderRepository.delete(order);

                return ResponseEntity.ok(order.getOrderId() + " canceled with reason: " + cancellationReason);
            } else {
                return ResponseEntity.badRequest().body("Cancellation reason is required.");
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    private void sendCancellationEmail(Order order, String cancellationReason) {
        /*
        String to = userRepository.findByRole("Owner").get().getEmail();
        String subject = "Customer Order Cancellation";
        String text = cancellationReason;

        emailService.sendSimpleMessage(to, subject, text);

        return ResponseEntity.ok("Email sent successfully");

         */
    }



}
