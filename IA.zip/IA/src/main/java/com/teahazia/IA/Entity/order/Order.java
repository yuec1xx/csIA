package com.teahazia.IA.Entity.order;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

// MongoDB annotation

@Document(collection = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {
    @Id
    private ObjectId orderId;
    private Date orderDate;
    private String orderStatus;
    private int totalCost;
    private List<productOrder> orderContent;

    // store customer ID as a reference.
    private ObjectId customerId;


    public Order(Date orderDate, String orderStatus, int totalCost, List<productOrder> orderContent, ObjectId customerId) {
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
        this.totalCost = totalCost;
        this.orderContent = orderContent;
        this.customerId = customerId;
    }
}
