package com.teahazia.IA.Entity.user;

import com.teahazia.IA.Entity.Products.product.Product;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class userService {
    @Autowired // instantiate repository class
    private com.teahazia.IA.Entity.user.userRepository userRepository;
    @Autowired
    private com.teahazia.IA.Entity.Products.product.productRepository productRepository;
    @Autowired
    private com.teahazia.IA.Entity.order.orderRepository orderRepository;



    public List<CustomerDTO> allCustomers() {
        List<User> users = userRepository.findByRole("Customer");
        return users.stream()
                .map(user -> new CustomerDTO(user.getName(), user.getEmail(), user.getMyOrders()))
                .collect(Collectors.toList());
    }

    public Optional<User> oneCustomer(ObjectId customerId){ // return a customer with the entered id
        return userRepository.findById(customerId);
    }

    public List<Product> getFavoriteProducts(List<Long> favoriteProductIds) { // return a list of product according to the list of product id
        List<Product> favoriteProducts = new ArrayList<>();

        // Iterate through the list of favorite product IDs
        for (Long productId : favoriteProductIds) {
            // Find the product with the given ID in the database
            Product product = productRepository.findById(productId).orElse(null);

            // Check if the product was found and add it to the list of favorite products
            if (product != null) {
                favoriteProducts.add(product);
            }
        }
        // Return the list of favorite products
        return favoriteProducts;
    }

    public String getCurrentAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (!(authentication instanceof AnonymousAuthenticationToken)) {
            // System.out.println(authentication.getName());
            return authentication.getName();
        }else{
            throw new IllegalStateException("No authenticated user found or user is not of type User.");
        }


    }




}
