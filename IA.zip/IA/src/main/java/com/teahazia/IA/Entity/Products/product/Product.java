package com.teahazia.IA.Entity.Products.product;

// mySQL Hibernate annotation

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity // Hibernate mapping annotation
@Inheritance(strategy = InheritanceType.JOINED) // part of a joined table inheritance strategy.
// allow storing common attributes in the parent table and specific attributes in the child tables.
@Data // Lombok annotation
@NoArgsConstructor
@AllArgsConstructor
public abstract class Product { // defined as abstract (base class) as subclasses must be created for Product to be instantiated
    @Id // mark as primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto increment in sql database
    @Column(nullable = false) // specify the column names for each field
    private Long productId;

    @Column(unique = true, nullable = false)
    private String productName;

    @Column(nullable = false)
    private int productPrice;

    @Column(nullable = false)
    private String productType; // discriminant property

    @Column(nullable = false)
    private Boolean available;

    @Column(columnDefinition = "VARCHAR(150)")
    private String productDescription;

    @Column(nullable = false)
    private int totalSales;

    // polymorphism; constructor without description.



    public Product(String productName, int productPrice, String productType, Boolean available, String productDescription, int totalSales) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productType = productType;
        this.available = available;
        this.productDescription = productDescription;
        this.totalSales = totalSales;
    }
}
