package com.teahazia.IA.Entity.Products.tea;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface teaRepository extends JpaRepository<Tea,Long> {
}
