package com.teahazia.IA.Entity.user;

// MongoDB annotation

import com.teahazia.IA.Entity.order.Order;
import com.teahazia.IA.Entity.order.productOrder;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;
import org.springframework.stereotype.Component;

import java.util.List;

@Document(collection = "users") // presents each document in the customers collection in mongoDB
@Data
@Builder
@AllArgsConstructor // constructor with all parameters
@NoArgsConstructor // constructor with no parameter
@Component
public class User { // from spring security, authorization and authentication
    @Id // annotate as unique identifier
    private ObjectId id;

    private String name;

    private String password;

    private String email;

    private String role; // either "CUSTOMER" or "OWNER"

    // store the ids of the products for reference
    private List<Long> favouriteProducts; // Specific to customers

    @DocumentReference // manual reference relationship, store only the order IDs, not embedding the Order
    private List<Order> myOrders; // Specific to customers

    private List<productOrder> cart;


    public User(String name, String password, String email, String role, List<Long> favouriteProducts, List<Order> myOrders, List<productOrder> cart) {
        this.name = name;
        this.password = password;
        this.email = email;
        this.role = role;
        this.favouriteProducts = favouriteProducts;
        this.myOrders = myOrders;
        this.cart = cart;
    }
}
