package com.teahazia.IA.Config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class JwtRequestFilter extends OncePerRequestFilter {

  private final JwtService jwtService;
  private final jwtUserDetailsService jwtUserDetailsService;

  @Override
  protected void doFilterInternal(
      @NonNull HttpServletRequest request, // able to intercept Http request
      @NonNull HttpServletResponse response, // add header to response
      @NonNull FilterChain chain // contains the other filters
  ) throws ServletException, IOException {

    final String header = request.getHeader("Authorization"); // jwt header
    if (header == null || !header.startsWith("Bearer ")) {
      chain.doFilter(request, response);
      return;
    }

    final String token = header.substring(7); // count Bearer with space
    final String email = jwtService.extractUsername(token); // get the user email

    if (email != null && SecurityContextHolder.getContext().getAuthentication() == null) {
      UserDetails userDetails;
      try {
        userDetails = jwtUserDetailsService.loadUserByUsername(email);
      } catch (UsernameNotFoundException e) {
        // Handle the case where the user is not found
        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
        return;
      }

      if (jwtService.isTokenValid(token, userDetails)) {
        UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                userDetails,
                null,
                userDetails.getAuthorities()
        );
        authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authToken);
      } else {
        // Handle the case where the token is not valid
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        return;
      }
    }
    chain.doFilter(request, response); // pass to the next filter
  }
}
