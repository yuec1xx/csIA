package com.teahazia.IA.Entity.order;

import com.teahazia.IA.Entity.Products.product.Product;
import com.teahazia.IA.Entity.Products.product.ProductDTO;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class productOrder {
    private static long counter = 0;
    @Id
    private Long productOrderId; // Use Long to allow null until an actual value is assigned

    @ManyToOne
    @JoinColumn(name = "productId") // Specifies the foreign key column in the database
    private ProductDTO productDTO; // store product ID as a reference.

    private int quantity; // product order

    private String orderCustomization;

    public productOrder(ProductDTO productDTO, int quantity, String orderCustomization) {
        this.productOrderId = ++counter; // generate unique identifier
        this.productDTO = productDTO;
        this.quantity = quantity;
        this.orderCustomization = orderCustomization;
    }
}
