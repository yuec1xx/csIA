package com.teahazia.IA.Entity.Products.pastry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class pastryService {
    @Autowired
    private pastryRepository pastryRepository;

    public Pastry createPastry(String productName, int productPrice, String productType,Boolean available, String productDescription, int totalSales, boolean glutenFree, int sweetness, String flavors){

        return pastryRepository.save(new Pastry(productName,productPrice,productType,available,productDescription,totalSales, glutenFree,sweetness,flavors));
    }
}
