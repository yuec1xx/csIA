package com.teahazia.IA;

import org.springframework.boot.SpringApplication; // contains run method for starting the Spring application
import org.springframework.boot.autoconfigure.SpringBootApplication; // contains Spring Boot annotation


@SpringBootApplication
public class teahazApplication {

	public static void main(String[] args) {
		SpringApplication.run(teahazApplication.class, args);
	}

}
